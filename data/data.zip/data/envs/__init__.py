import gym

gym.envs.register(
    id='DarkRoom-v0',
    entry_point='envs.darkroom:DarkRoom',
)
